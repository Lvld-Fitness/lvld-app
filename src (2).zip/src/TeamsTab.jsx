export default function TeamsTab() {
  return (
    <div className="text-white bg-black min-h-screen flex items-center justify-center">
      <h1 className="text-2xl font-bold">Team Challenges Coming Soon!</h1>
    </div>
  );
}