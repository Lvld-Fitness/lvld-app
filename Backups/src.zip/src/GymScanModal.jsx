// New GymScanModal.jsx content here
