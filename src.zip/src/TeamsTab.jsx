import { useState } from "react";
import { UserCirclePlus, MagnifyingGlass } from "phosphor-react";
import "./TeamsTab.css";

export default function TeamsTab() {
  const [showCreateTeamModal, setShowCreateTeamModal] = useState(false);
  const [showJoinTeamModal, setShowJoinTeamModal] = useState(false);

  const handleCreateTeam = () => {
    setShowCreateTeamModal(true);
  };

  const handleJoinTeam = () => {
    setShowJoinTeamModal(true);
  };

  return (
    <div className="teams-tab">
      <div className="teams-header">
        <h2>Teams</h2>
      </div>

      <div className="teams-actions">
        <button className="action-button" onClick={handleCreateTeam}>
          <UserCirclePlus size={24} /> Create Team
        </button>

        <button className="action-button" onClick={handleJoinTeam}>
          <MagnifyingGlass size={24} /> Join Team
        </button>
      </div>

      <div className="teams-search">
        <input
          type="text"
          placeholder="Search for a team..."
          className="search-input"
        />
      </div>
    </div>
  );
}
